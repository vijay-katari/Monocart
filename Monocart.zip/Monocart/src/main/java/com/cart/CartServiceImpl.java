package com.cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Product.Product;
import com.Product.ProductRepository;
import com.user.User;
import com.user.UserRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepo;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private ProductRepository productRepo;

    @SuppressWarnings("unused")
	@Autowired
    private CartItemRepository cartItemRepo;

    @Override
    public Cart addToCart(Long userId, Long productId, int quantity) {
        User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Product product = productRepo.findById(productId).orElseThrow(() -> new RuntimeException("Product not found"));

        Cart cart = cartRepo.findByUserUserId(userId);
        if (cart == null) {
            cart = new Cart();
            cart.setUser(user);
            cart.setItems(new ArrayList<>());
        }

        CartItem item = new CartItem(cart, product, quantity);
        cart.getItems().add(item);

        double total = cart.getItems().stream()
        		.mapToDouble(i -> Double.parseDouble((String) i.getProduct().getPrice()) * i.getQuantity())

                .sum();
        cart.setTotalPrice(total);

        return cartRepo.save(cart);
    }

    @Override
    public Cart getCartByUserId(Long userId) {
        return cartRepo.findByUserUserId(userId);
    }

    @Override
    public void removeItem(Long cartId, Long itemId) {
        Cart cart = cartRepo.findById(cartId)
            .orElseThrow(() -> new RuntimeException("Cart not found"));

        cart.getItems().removeIf(i -> i.getItemId().equals(itemId));

        double total = cart.getItems().stream()
        		.mapToDouble(i -> Double.parseDouble((String) i.getProduct().getPrice()) * i.getQuantity())
            .sum();

        cart.setTotalPrice(total);
        cartRepo.save(cart);
    }


    @Override
    public void clearCart(Long cartId) {
        Cart cart = cartRepo.findById(cartId).orElseThrow(() -> new RuntimeException("Cart not found"));
        cart.getItems().clear();
        cart.setTotalPrice(0);
        cartRepo.save(cart);
    }

    @Override
    public List<Cart> getAllCarts() {
        return cartRepo.findAll();
    }
}
