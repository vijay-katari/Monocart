package com.cart;
import java.util.List;

public interface CartService {
    Cart addToCart(Long userId, Long productId, int quantity);
    Cart getCartByUserId(Long userId);
    void removeItem(Long cartId, Long itemId);
    void clearCart(Long cartId);
    List<Cart> getAllCarts();
}

