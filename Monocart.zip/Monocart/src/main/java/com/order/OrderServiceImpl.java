package com.order;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Product.ProductRepository;
import com.cart.Cart;
import com.cart.CartItem;
import com.cart.CartRepository;
import com.user.User;
import com.user.UserRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private CartRepository cartRepo;

    @Autowired
    private OrderRepository orderRepo;

    @SuppressWarnings("unused")
	@Autowired
    private ProductRepository productRepo;

    @Override
    public Order placeOrder(Long userId) {
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));

        Cart cart = cartRepo.findByUserUserId(userId);
        if (cart == null || cart.getItems().isEmpty()) {
            throw new RuntimeException("Cart is empty for user: " + userId);
        }

        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem ci : cart.getItems()) {
            OrderItem oi = new OrderItem();
            oi.setProduct(ci.getProduct());
            oi.setQuantity(ci.getQuantity());
            orderItems.add(oi);
        }

        double total = orderItems.stream()
        		.mapToDouble(i -> Double.parseDouble((String) i.getProduct().getPrice()) * i.getQuantity())

        		.sum();
        		

        Order order = new Order();
        order.setUser(user);
        order.setItems(orderItems);
        order.setTotalAmount(total);
        order.setStatus(OrderStatus.NEW);

        // Set back-reference for each OrderItem
        for (OrderItem oi : orderItems) {
            oi.setOrder(order);
        }

        // Clear the cart after placing order
        cart.getItems().clear();
        cart.setTotalPrice(0);
        cartRepo.save(cart);

        return orderRepo.save(order);
    }

    @Override
    public List<Order> getOrdersByUser(Long userId) {
        return orderRepo.findByUserUserId(userId);
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    @Override
    public Order updateOrderStatus(Long orderId, OrderStatus status) {
        Order order = orderRepo.findById(orderId)
            .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        order.setStatus(status);
        return orderRepo.save(order);
    }
}
