package com.Product;
import com.category.Category;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;

    private String name;
    @SuppressWarnings("unused")
	private String description;
    @SuppressWarnings("unused")
	private Double price;
    @SuppressWarnings("unused")
	private Integer quantity;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category; // You'll define Category class later

    // Constructors
    public Product() {
    }

    public Product(String name, String description, Double price, Integer quantity) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters and Setters
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
    }

	public Object getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setDescription(Object description2) {
		// TODO Auto-generated method stub
		
	}

	public Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setPrice(Object price2) {
		// TODO Auto-generated method stub
		
	}

	public Object getQuantity() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setQuantity(Object quantity2) {
		// TODO Auto-generated method stub
		
	}

	public Object getCategory() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCategory(Object category2) {
		// TODO Auto-generated method stub
		
	}
   }
